var express = require('express');
var router = express.Router();
var controllers = require('../controllers/Process');
var middleware = require('../controllers/Auth');

/* GET users listing. */
router.get('/', middleware.auth, controllers.getMethod);
router.post('/post', middleware.auth, controllers.postMethod);

module.exports = router;
