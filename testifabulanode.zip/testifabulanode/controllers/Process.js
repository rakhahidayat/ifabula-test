
exports.getMethod = function(req, res)
{
    res.status(200).json({
        error: false,
        message: 'Call Get API succeed'
    })
}

exports.postMethod = function(req, res)
{
    res.status(200).json({
        error: false,
        message: "Call Get API succeed, the value is: "+req.body.data
    })
}