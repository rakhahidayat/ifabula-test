
exports.auth = function (req, res, next){
    if(req.header('User-id') && req.header('User-id') == 'ifabula')
    {
        if(req.header('Scope') && req.header('Scope') == 'user')
        {
            next();
        }
        else
        {
            res.status(401).json({
                responseCode: 401,
                responseMessage: "UNAUTHORIZED"

            })
        }
    }
    else
    {
        res.status(401).json({
            responseCode: 401,
            responseMessage: "UNAUTHORIZED"

        })
    }
}